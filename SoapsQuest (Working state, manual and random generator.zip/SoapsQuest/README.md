# SoapsQuest

A lightweight Minecraft quest plugin for Paper servers using physical quest papers to track progress.

## Features

- **28 Quest Types** - Kill, Break, Collect, Craft, Fish, MythicMobs, and more
- **Physical Quest Papers** - Real items bound to players with live progress updates
- **Quest Tiers** - COMMON, RARE, EPIC, LEGENDARY with colored prefixes
- **Milestones** - Progress notifications at custom percentages
- **Reward Chances** - Randomized rewards with configurable drop rates
- **Multi-Objective Quests** - Sequential or parallel objective completion
- **Rich Rewards** - XP, money (Vault), items with enchantments, commands
- **Hot-Reload** - Update configuration without restart
- **Async Saving** - Auto-save player data without lag

## Requirements

- **Paper** 1.20.4+ (or any Paper-based server)
- **Java** 21+
- **Vault** (optional, for money rewards)
- **MythicMobs** (optional, for MythicMobs quests)

## Installation

1. Download `SoapsQuest-X.X.X.jar` from releases
2. Place in `plugins/` folder
3. Restart server
4. Edit `plugins/SoapsQuest/quests.yml` to configure quests
5. Customize messages in `messages.yml`

## Commands

All commands use `/soapsquest` or `/sq` alias.

| Command | Description |
|---------|-------------|
| `/sq give <player> <quest>` | Give a quest paper |
| `/sq list` | List all quests |
| `/sq reload` | Reload configuration |
| `/sq progress [player]` | Check quest progress |
| `/sq addreward <quest>` | Add held item as reward |
| `/sq removereward <quest> <index>` | Remove reward by index |

**Default permissions:** All commands require `soapsquest.*` (op) except `/sq list` and `/sq progress` (all players).

## Configuration

**quests.yml** - Define all quests with full documentation in-file  
**config.yml** - Plugin settings (autosave interval, display options)  
**messages.yml** - Customizable messages with color code support

### Example Quest

```yaml
diamond_collector:
  type: collect
  item: DIAMOND
  amount: 10
  display: "&b&lDiamond Collector"
  tier: EPIC                    # Purple [EPIC] prefix
  milestones: [50]              # Progress notification at 50%
  lock-to-player: true
  reward:
    xp: 300
    items:
      - material: DIAMOND_PICKAXE
        name: "&bLucky Pickaxe"
        enchantments:
          - "LOOT_BONUS_BLOCKS:3"
        chance: 100             # 100% drop rate
      - material: DIAMOND
        amount: 3
        chance: 50              # 50% chance for bonus diamonds
```

### Quest Types

**Combat:** kill, kill_mythicmob, damage, death  
**Building:** break, place  
**Gathering:** collect, fish, shear  
**Crafting:** craft, smelt, brew, enchant  
**Social:** trade, interact, chat, command  
**Survival:** consume, tame, sleep, heal, level  
**Movement:** move, ride_vehicle  
**Special:** shoot_bow, launch_firework, placeholder

### Reward Types

- **XP** - Experience points with optional chance
- **Money** - Requires Vault plugin, with optional chance
- **Items** - Custom items with enchantments, lore, and drop chance
- **Commands** - Execute any server command with `<player>` placeholder

### Quest Features

- **Tiers:** COMMON, RARE, EPIC, LEGENDARY (colored name prefixes)
- **Milestones:** Progress notifications at custom percentages [25, 50, 75]
- **Sequential Mode:** Complete objectives in specific order
- **Multi-Objective:** Combine multiple objectives in one quest
- **Entity Filters:** ANY, HOSTILE, PASSIVE, or specific entity types
- **Reward Chances:** Randomized drops (0-100% per reward)

## Building

```bash
git clone https://github.com/yourusername/SoapsQuest.git
cd SoapsQuest
mvn clean package
```

Output: `target/SoapsQuest-X.X.X.jar`

---

**Author:** AlternativeSoap  
**Website:** www.soapsuniverse.com  
**Support:** GitHub Issues
